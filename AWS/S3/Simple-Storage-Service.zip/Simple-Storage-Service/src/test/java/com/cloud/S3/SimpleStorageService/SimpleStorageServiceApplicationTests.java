package com.cloud.S3.SimpleStorageService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleStorageServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
