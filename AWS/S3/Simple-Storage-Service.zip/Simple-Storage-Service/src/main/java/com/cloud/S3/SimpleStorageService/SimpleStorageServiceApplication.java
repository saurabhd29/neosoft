package com.cloud.S3.SimpleStorageService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleStorageServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleStorageServiceApplication.class, args);
	}

}
