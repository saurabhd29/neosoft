package com.s3upload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoS3UploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoS3UploadApplication.class, args);
	}

}
