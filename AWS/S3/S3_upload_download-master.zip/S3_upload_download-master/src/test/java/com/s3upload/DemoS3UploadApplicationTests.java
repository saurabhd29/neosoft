package com.s3upload;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoS3UploadApplicationTests {

	@Test
	void contextLoads() {
	}

}
